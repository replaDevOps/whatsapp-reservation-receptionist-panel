export const selfbookingData = [
    {
        key: 1,
        name: 'Branch Name 01',
        username:'BR1',
        password: 'Branch0011',
        accessibility: 'Logged In',
        status: 'Active'
    },
    {
        key: 2,
        name: 'Branch Name 02',
        username:'BR2',
        password: 'Branch0022',
        accessibility: 'Logged Out',
        status: 'Inactive'
    },
    {
        key: 3,
        name: 'Branch Name 03',
        username:'BR3',
        password: 'Branch0033',
        accessibility: 'Logged In',
        status: 'Inactive'
    },
    {
        key: 4,
        name: 'Branch Name 04',
        username:'BR4',
        password: 'Branch0044',
        accessibility: 'Logged Out',
        status: 'Active'
    },
]